package com.example.simplesms

import android.app.Service
import android.content.*
import android.os.IBinder

class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {}
}

class RespondService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}

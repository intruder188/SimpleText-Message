package com.example.simplesms

import android.app.*
import android.content.*
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (msgs.isEmpty()) return
        val addr = msgs[0].originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val v = ContentValues().apply {
            put(Telephony.Sms.ADDRESS, addr)
            put(Telephony.Sms.BODY, body)
            put(Telephony.Sms.DATE, System.currentTimeMillis())
            put(Telephony.Sms.READ, 0)
        }
        c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v)

        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sms", "Messages", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(
            c, addr.hashCode(),
            Intent(c, ThreadActivity::class.java).putExtra("address", addr),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nm.notify(addr.hashCode(), Notification.Builder(c, "sms")
            .setSmallIcon(android.R.drawable.sym_action_email)
            .setContentTitle(addr).setContentText(body)
            .setContentIntent(open).setAutoCancel(true).build())
    }
}

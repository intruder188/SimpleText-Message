package com.example.simplesms

import android.app.Activity
import android.content.ContentValues
import android.os.Bundle
import android.provider.Telephony
import android.telephony.SmsManager
import android.view.WindowInsets
import android.widget.*

class ThreadActivity : Activity() {
    private lateinit var address: String
    private lateinit var list: ListView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        address = intent.getStringExtra("address") ?: run { finish(); return }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.setOnApplyWindowInsetsListener { v, ins ->
            val s = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            v.setPadding(s.left, s.top, s.right, s.bottom); ins
        }
        root.addView(TextView(this).apply { text = address; textSize = 20f; setPadding(32, 24, 32, 24) })
        list = ListView(this).apply { transcriptMode = ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL; divider = null }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this)
        val et = EditText(this).apply { hint = "Message" }
        row.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = "Send"
            setOnClickListener {
                val t = et.text.toString()
                if (t.isNotBlank()) { send(t); et.setText(""); load() }
            }
        })
        root.addView(row)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); load() }

    private fun send(text: String) {
        try {
            val sm = getSystemService(SmsManager::class.java)
            sm.sendMultipartTextMessage(address, null, sm.divideMessage(text), null, null)
            if (Telephony.Sms.getDefaultSmsPackage(this) == packageName) {
                contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, ContentValues().apply {
                    put(Telephony.Sms.ADDRESS, address)
                    put(Telephony.Sms.BODY, text)
                    put(Telephony.Sms.DATE, System.currentTimeMillis())
                })
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Send failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun load() {
        val rows = ArrayList<String>()
        contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("body", "type"),
            "address = ?", arrayOf(address), "date ASC")?.use { c ->
            while (c.moveToNext()) {
                val mine = c.getInt(1) != Telephony.Sms.MESSAGE_TYPE_INBOX
                rows.add((if (mine) "Me: " else "") + c.getString(0))
            }
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
    }
}

package com.example.simplesms

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Telephony
import android.view.Gravity
import android.view.WindowInsets
import android.widget.*

class MainActivity : Activity() {
    private val addrs = ArrayList<String>()
    private lateinit var list: ListView
    private lateinit var banner: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.setOnApplyWindowInsetsListener { v, ins ->
            val s = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            v.setPadding(s.left, s.top, s.right, s.bottom); ins
        }
        root.addView(TextView(this).apply { text = "Text Message"; textSize = 22f; setPadding(32, 24, 32, 24) })
        banner = Button(this).apply { text = "Set as default SMS app"; setOnClickListener { askDefault() } }
        root.addView(banner)
        val newBtn = Button(this).apply {
            text = "New message"
            setOnClickListener { askNumber() }
        }
        root.addView(newBtn)
        root.addView(Button(this).apply {
            text = "Add fake message (this phone only)"
            setOnClickListener { askFake() }
        })
        list = ListView(this)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        list.setOnItemClickListener { _, _, pos, _ ->
            startActivity(Intent(this, ThreadActivity::class.java).putExtra("address", addrs[pos]))
        }
        setContentView(root)

        requestPermissions(arrayOf(
            Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS, Manifest.permission.POST_NOTIFICATIONS), 1)

        intent?.data?.let { d ->
            if (d.scheme in listOf("sms", "smsto", "mms", "mmsto")) {
                val n = d.schemeSpecificPart.substringBefore("?")
                if (n.isNotBlank()) startActivity(Intent(this, ThreadActivity::class.java).putExtra("address", n))
            }
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); refresh()
    }

    private fun isDefault() = Telephony.Sms.getDefaultSmsPackage(this) == packageName

    private fun askDefault() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleAvailable(RoleManager.ROLE_SMS))
            @Suppress("DEPRECATION") startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 2)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) { super.onActivityResult(rc, res, d); refresh() }

    private fun askNumber() {
        val et = EditText(this).apply { hint = "Phone number"; inputType = android.text.InputType.TYPE_CLASS_PHONE }
        android.app.AlertDialog.Builder(this).setTitle("New message").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) startActivity(Intent(this, ThreadActivity::class.java).putExtra("address", n))
            }.setNegativeButton("Cancel", null).show()
    }

    private fun askFake() {
        if (!isDefault()) {
            Toast.makeText(this, "Set this app as default SMS app first", Toast.LENGTH_LONG).show(); return
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0) }
        val who = EditText(this).apply { hint = "Sender name or number" }
        val msg = EditText(this).apply { hint = "Message text" }
        box.addView(who); box.addView(msg)
        android.app.AlertDialog.Builder(this).setTitle("Add fake incoming message").setView(box)
            .setPositiveButton("Add") { _, _ ->
                val a = who.text.toString().trim(); val t = msg.text.toString()
                if (a.isNotEmpty() && t.isNotEmpty()) {
                    contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, android.content.ContentValues().apply {
                        put(Telephony.Sms.ADDRESS, a); put(Telephony.Sms.BODY, t)
                        put(Telephony.Sms.DATE, System.currentTimeMillis()); put(Telephony.Sms.READ, 1)
                    })
                    refresh()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun refresh() {
        banner.visibility = if (isDefault()) android.view.View.GONE else android.view.View.VISIBLE
        if (checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return
        val latest = LinkedHashMap<String, String>()
        contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("address", "body"),
            null, null, "date DESC")?.use { c ->
            while (c.moveToNext() && latest.size < 300) {
                val a = c.getString(0) ?: continue
                if (a !in latest) latest[a] = c.getString(1) ?: ""
            }
        }
        addrs.clear(); addrs.addAll(latest.keys)
        list.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_2, android.R.id.text1, addrs) {
            override fun getView(pos: Int, cv: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val v = super.getView(pos, cv, parent)
                v.findViewById<TextView>(android.R.id.text2).apply { text = latest[addrs[pos]]; maxLines = 1 }
                return v
            }
        }
    }
}
